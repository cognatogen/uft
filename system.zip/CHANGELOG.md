# Changelog

This file is deprecated.

## 1.2.2 and earlier

For a detailed description of changes for releases 1.2.2 and earlier, visit the [CHANGELOG.md](https://gitlab.com/mesfoliesludiques/foundryvtt-ose/-/blob/master/CHANGELOG.md) page in **mesfoliesludiques/foundryvtt-ose** on GitLab.

## Recent Releases

For a detailed description of changes for releases after 1.2.2, please see the [releases](https://github.com/vttred/ose/releases) page of this repository.
