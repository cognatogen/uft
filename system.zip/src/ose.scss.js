/**
 * @file This file is used as an entry point for rollup
 *       to allow for in-place updates of CSS.
 *       Do not include any additional code in this file.
 */
import "./ose.scss";
